
import React from 'react';
import { motion } from 'framer-motion';
import { Search, Database, Zap } from 'lucide-react';

const steps = [
  {
    icon: Search,
    title: 'Select & Search',
    description: 'Choose your state from the dropdown and enter the city name you want to look up.',
  },
  {
    icon: Database,
    title: 'Database Lookup',
    description: 'Our system searches through a comprehensive database of US cities and their time zones.',
  },
  {
    icon: Zap,
    title: 'Instant Results',
    description: 'Get the IANA time zone identifier and short label instantly displayed on your screen.',
  },
];

const HowItWorks = () => {
  return (
    <section className="py-16 px-4 bg-gray-50">
      <div className="container mx-auto max-w-6xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            How It Works
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Finding the correct time zone for any US city is simple and fast
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300 border border-purple-100"
            >
              <div className="flex items-center justify-center w-16 h-16 bg-gradient-to-br from-[#5B3FA0] to-[#8B5CF6] rounded-2xl mb-6 mx-auto">
                <step.icon className="w-8 h-8 text-white" />
              </div>

              <h3 className="text-xl font-bold text-gray-900 mb-3 text-center">
                {step.title}
              </h3>

              <p className="text-gray-600 text-center leading-relaxed">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;
