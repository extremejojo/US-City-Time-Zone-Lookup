import React from 'react';
import { Clock, Github, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-br from-gray-900 to-gray-800 text-white py-12 px-4">
      <div className="container mx-auto max-w-6xl">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <Clock className="w-6 h-6 text-purple-400" />
              <span className="text-xl font-bold">TimeZone Finder</span>
            </div>
            <p className="text-gray-400 leading-relaxed">
              Your trusted source for accurate US city time zone information.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="#lookup-tool" className="text-gray-400 hover:text-purple-400 transition-colors">
                  Lookup Tool
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                  About IANA
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-purple-400 transition-colors">
                  How It Works
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Connect</h3>
            <div className="flex gap-4">
              <a 
                href="#" 
                className="flex items-center justify-center w-10 h-10 bg-gray-700 hover:bg-purple-600 rounded-lg transition-colors"
                aria-label="GitHub"
              >
                <Github className="w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="flex items-center justify-center w-10 h-10 bg-gray-700 hover:bg-purple-600 rounded-lg transition-colors"
                aria-label="Email"
              >
                <Mail className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8 text-center">
          <p className="text-gray-400">
            © {new Date().getFullYear()} US City Time Zone Finder. All rights reserved. <p>Made with &#128156; by JoJo</p>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;