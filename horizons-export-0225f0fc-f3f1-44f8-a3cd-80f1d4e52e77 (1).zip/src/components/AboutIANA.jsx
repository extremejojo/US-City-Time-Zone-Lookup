
import React from 'react';
import { motion } from 'framer-motion';
import { Globe, Info } from 'lucide-react';

const AboutIANA = () => {
  return (
    <section className="py-16 px-4">
      <div className="container mx-auto max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 border border-purple-100"
        >
          <div className="flex items-center gap-3 mb-6">
            <div className="flex items-center justify-center w-12 h-12 bg-gradient-to-br from-[#5B3FA0] to-[#8B5CF6] rounded-xl">
              <Globe className="w-6 h-6 text-white" />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900">
              About IANA Time Zones
            </h2>
          </div>

          <div className="space-y-6 text-gray-700 leading-relaxed">
            <p>
              The <strong>IANA Time Zone Database</strong> (also known as the tz database or Olson database) 
              is the standard reference for time zone information used by computers and software worldwide.
            </p>

            <div className="bg-purple-50 border-l-4 border-[#5B3FA0] p-6 rounded-r-xl">
              <div className="flex items-start gap-3">
                <Info className="w-5 h-5 text-[#5B3FA0] mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-bold text-gray-900 mb-2">Why IANA Time Zones Matter</h3>
                  <p className="text-gray-700">
                    IANA time zone identifiers (like "America/New_York" or "America/Los_Angeles") 
                    are used by programming languages, databases, and applications to accurately 
                    handle time conversions, daylight saving time changes, and historical time zone data.
                  </p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-bold text-gray-900 mb-3 text-xl">Common US Time Zones</h3>
              <ul className="space-y-2 ml-6">
                <li className="flex items-start gap-2">
                  <span className="text-[#5B3FA0] font-bold">•</span>
                  <span><strong>America/New_York</strong> - Eastern Time (ET)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#5B3FA0] font-bold">•</span>
                  <span><strong>America/Chicago</strong> - Central Time (CT)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#5B3FA0] font-bold">•</span>
                  <span><strong>America/Denver</strong> - Mountain Time (MT)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#5B3FA0] font-bold">•</span>
                  <span><strong>America/Los_Angeles</strong> - Pacific Time (PT)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#5B3FA0] font-bold">•</span>
                  <span><strong>America/Phoenix</strong> - Mountain Time (no DST)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#5B3FA0] font-bold">•</span>
                  <span><strong>America/Anchorage</strong> - Alaska Time (AKT)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#5B3FA0] font-bold">•</span>
                  <span><strong>Pacific/Honolulu</strong> - Hawaii-Aleutian Time (no DST)</span>
                </li>
              </ul>
            </div>

            <p>
              This tool helps developers, system administrators, and anyone working with time-sensitive 
              applications quickly find the correct IANA identifier for any US city.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default AboutIANA;
