
import React from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { LatLng } from 'leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default marker icon issue with webpack
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png'
});

const ChangeView = ({ center, zoom }) => {
  const map = useMap();
  map.setView(center, zoom);
  return null;
};

const USAMap = ({ coordinates, cityName }) => {
  if (!coordinates || !coordinates.lat || !coordinates.lon) {
    // Default view centered on the US if no coordinates
    return (
      <MapContainer center={[39.8283, -98.5795]} zoom={4} style={{ height: '400px', width: '100%', borderRadius: '1rem', zIndex: 0 }}>
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
      </MapContainer>
    );
  }

  const position = new LatLng(coordinates.lat, coordinates.lon);

  return (
    <div className="relative aspect-[16/10] w-full rounded-2xl overflow-hidden border-2 border-purple-200 shadow-lg">
      <MapContainer center={position} zoom={10} scrollWheelZoom={false} style={{ height: '100%', width: '100%', zIndex: 0 }}>
        <ChangeView center={position} zoom={10} />
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        <Marker position={position}>
          <Popup>
            {cityName}
          </Popup>
        </Marker>
      </MapContainer>
    </div>
  );
};

export default USAMap;
