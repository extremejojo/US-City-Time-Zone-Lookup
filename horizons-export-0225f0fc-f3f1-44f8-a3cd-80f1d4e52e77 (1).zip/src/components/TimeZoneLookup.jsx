
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, MapPin, Clock, Compass } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Combobox } from '@/components/ui/combobox';
import { toast } from '@/components/ui/use-toast';
import USAMap from '@/components/USAMap';
import citiesData from '@/data/cities_with_coords.json';

const TimeZoneLookup = () => {
  const [selectedState, setSelectedState] = useState('');
  const [cityInput, setCityInput] = useState('');
  const [result, setResult] = useState(null);
  const [states, setStates] = useState([]);
  const [citiesInState, setCitiesInState] = useState([]);

  useEffect(() => {
    const uniqueStates = [...new Set(citiesData.map(city => city.state))].sort();
    setStates(uniqueStates);
  }, []);

  useEffect(() => {
    if (selectedState) {
      const filteredCities = citiesData
        .filter(city => city.state === selectedState)
        .map(city => ({ value: city.name.toLowerCase(), label: city.name }));
      setCitiesInState(filteredCities);
    } else {
      setCitiesInState([]);
    }
    setCityInput('');
    setResult(null);
  }, [selectedState]);

  const formatTimeZoneDisplay = (ianaTimeZone, shortLabel) => {
    switch (ianaTimeZone) {
      case 'America/Chicago':
        return `Central Time (${shortLabel})`;
      case 'America/New_York':
        return `Eastern Time (${shortLabel})`;
      case 'Pacific/Honolulu':
        return `Hawaii-Aleutian Time (no DST)`;
      case 'America/Anchorage':
        return `Alaska Time (${shortLabel})`;
      case 'America/Adak':
        return `Hawaii-Aleutian Time (${shortLabel})`; // Adak is HAT
      case 'America/Phoenix':
        return `Mountain Standard Time (${shortLabel})`; // MST for AZ
      case 'America/Denver':
        return `Mountain Time (${shortLabel})`;
      case 'America/Los_Angeles':
        return `Pacific Time (${shortLabel})`;
      case 'America/Boise':
        return `Mountain Time (${shortLabel})`; // Specific for some ID areas
      case 'America/Indiana/Indianapolis':
        return `Eastern Time (${shortLabel})`;
      case 'America/Kentucky/Louisville':
        return `Eastern Time (${shortLabel})`;
      case 'America/Detroit':
        return `Eastern Time (${shortLabel})`;
      case 'America/Menominee':
        return `Central Time (${shortLabel})`;
      default:
        const parts = ianaTimeZone.split('/');
        const zoneName = parts[parts.length - 1].replace(/_/g, ' ');
        return `${zoneName} Time (${shortLabel})`;
    }
  };

  const handleSearch = () => {
    if (!selectedState || !cityInput) {
      toast({
        title: "Missing Information",
        description: "Please select a state and a city.",
        variant: "destructive",
      });
      return;
    }

    const foundCity = citiesData.find(
      city => 
        city.state === selectedState && 
        city.name.toLowerCase() === cityInput.toLowerCase()
    );

    if (foundCity) {
      setResult(foundCity);
      toast({
        title: "Time Zone Found!",
        description: `${foundCity.name}, ${foundCity.state} is in ${foundCity.timezone}`,
      });
    } else {
      setResult(null);
      toast({
        title: "City Not Found",
        description: `No time zone data found for "${cityInput}" in ${selectedState}. Please check your selection.`,
        variant: "destructive",
      });
    }
  };
  
  const handleStateChange = (state) => {
    setSelectedState(state);
    setCityInput('');
  };

  return (
    <section id="lookup-tool" className="py-16 px-4">
      <div className="container mx-auto max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 border border-purple-100"
        >
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
              Time Zone Lookup Tool
            </h2>
            <p className="text-gray-600">
              Select a state and enter a city name to find its time zone
            </p>
          </div>

          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="state-select" className="text-gray-700 font-semibold">
                  State
                </Label>
                <Select value={selectedState} onValueChange={handleStateChange}>
                  <SelectTrigger id="state-select" className="h-12 rounded-xl border-2 border-gray-200 focus:border-[#5B3FA0] transition-colors">
                    <SelectValue placeholder="Select a state" />
                  </SelectTrigger>
                  <SelectContent>
                    {states.map(state => (
                      <SelectItem key={state} value={state}>
                        {state}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="city-input" className="text-gray-700 font-semibold">
                  City Name
                </Label>
                <Combobox
                  options={citiesInState}
                  value={cityInput}
                  onChange={setCityInput}
                  disabled={!selectedState}
                  placeholder="Select a city"
                  searchPlaceholder="Search city..."
                  notFoundMessage="No city found."
                />
              </div>
            </div>

            <Button
              onClick={handleSearch}
              className="w-full h-12 bg-gradient-to-r from-[#5B3FA0] to-[#8B5CF6] hover:from-[#4A2F80] hover:to-[#7A4CE6] text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-[1.02]"
            >
              <Search className="w-5 h-5 mr-2" />
              Search Time Zone
            </Button>
          </div>

          <AnimatePresence>
            {result && (
              <motion.div
                initial={{ opacity: 0, height: 0, marginTop: 0 }}
                animate={{ opacity: 1, height: 'auto', marginTop: '2rem' }}
                exit={{ opacity: 0, height: 0, marginTop: 0 }}
                transition={{ duration: 0.5, ease: 'easeInOut' }}
                className="overflow-hidden"
              >
                <div className="p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl border-2 border-purple-200">
                  <div className="grid md:grid-cols-2 gap-6 items-start">
                    <div className="space-y-4">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-6 h-6 text-[#5B3FA0]" />
                        <h3 className="text-2xl font-bold text-gray-900">Results</h3>
                      </div>
                      <div className="flex items-start gap-3">
                        <span className="font-semibold text-gray-700 min-w-[120px]">City:</span>
                        <span className="text-gray-900">{result.name}</span>
                      </div>
                      <div className="flex items-start gap-3">
                        <span className="font-semibold text-gray-700 min-w-[120px]">State:</span>
                        <span className="text-gray-900">{result.state}</span>
                      </div>
                      <div className="flex items-start gap-3">
                         <Clock className="w-5 h-5 text-[#5B3FA0] mt-0.5" />
                        <div className="flex-1">
                          <div className="flex items-start gap-3">
                            <span className="font-semibold text-gray-700 min-w-[100px]">Time Zone:</span>
                            <span className="text-gray-900 font-mono bg-white px-3 py-1 rounded-lg">
                              {formatTimeZoneDisplay(result.timezone, result.shortLabel)}
                            </span>
                          </div>
                        </div>
                      </div>
                        <div className="flex items-start gap-3">
                         <Compass className="w-5 h-5 text-[#5B3FA0] mt-0.5" />
                        <div className="flex-1">
                          <div className="flex items-start gap-3">
                            <span className="font-semibold text-gray-700 min-w-[100px]">Coordinates:</span>
                             <span className="text-gray-900 font-mono bg-white px-3 py-1 rounded-lg">
                              {result.lat}, {result.lon}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <USAMap coordinates={{ lat: result.lat, lon: result.lon }} cityName={result.name} />
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
};

export default TimeZoneLookup;
