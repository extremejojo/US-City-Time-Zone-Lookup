
import React from 'react';
import { Helmet } from 'react-helmet';
import Hero from '@/components/Hero';
import TimeZoneLookup from '@/components/TimeZoneLookup';
import HowItWorks from '@/components/HowItWorks';
import AboutIANA from '@/components/AboutIANA';
import Footer from '@/components/Footer';
import { Toaster } from '@/components/ui/toaster';

function App() {
  return (
    <>
      <Helmet>
        <title>US City Time Zone Finder — Instant Time Zone Lookup</title>
        <meta 
          name="description" 
          content="Search any U.S. city and get the correct IANA time zone instantly." 
        />
      </Helmet>
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-purple-50">
        <Hero />
        <TimeZoneLookup />
        <HowItWorks />
        <AboutIANA />
        <Footer />
        <Toaster />
      </div>
    </>
  );
}

export default App;
